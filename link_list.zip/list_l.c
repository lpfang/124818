//
//  list_l.c
//  List_L
//
//  Created by siqi on 13-10-6.
//  Copyright (c) 2013年 siqi. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include "list_l.h"




Status InitList_L(LinkList *L){
    L->head = (LNode *)malloc(sizeof(LNode));
    if (L) {
        L->head->next = NULL;
        return OK;
    }
    return ERROR;
}

int  ListLength_L(LinkList L) {
    
    int len = 0;
    LNode  *p;
    
    for (p = L.head; p->next !=NULL; p = (LNode *)p->next) {
        ++len;
    }
    return len;
}

int isEmpty_L(LinkList L){
    LNode * p;
    
    p = L.head;
    if (p->next == NULL) {
        return TRUE;
    }
    else
        return FALSE;
}

Status GetElem_L(LinkList L, int i, ElemType * e) {
    LNode * p;
    int j = 1;
    
    p = L.head;
    while (p && j < i) {
        ++j;
        p=(LNode *)p->next;
    }
    if (j > i || p==NULL) {
        return ERROR;
    }
    *e = p->data;
    return OK;
}

LNode * PreviousElem_L(LinkList L, LNode* e){
    LNode * p;
    
    p=L.head;
    if (p==e) {
        return NULL;
    }
    for (p=L.head; p->next && (LNode*)p->next!=e; p=(LNode*)p->next)
        ;
    if ((LNode*)p->next==e) {
        return p;
    }
    return NULL;
}

LNode* NextElem_L(LinkList L, LNode*e){
    LNode *p;
    
    for (p=(LNode*)L.head->next; p&&p!=e; p=(LNode*)p->next) ;
    if (p==e) {
        return (LNode*)p->next;
    }
    return NULL;
}

Status ListInsert_L(LinkList *L, int i, ElemType e){
    LNode * s, *p;
    int j;
    
    if (i<1 || i>ListLength_L(*L)+1) {
        return ERROR;
    }
    s = (LNode *)malloc(sizeof(LNode)) ;
    if (!s) {
        return ERROR;
    }
    
    for (j = 0, p=(LNode*)L->head; p && j<i-1; ++j,p=(LNode*)p->next)
        ;
    s->data = e;
    s->next = p->next;
    p->next = (struct LNode *)s;
    return OK;
    
}

Status  ListDelete_L(LinkList *L, int i, ElemType *e){
    int j;
    LNode *p,*q;
    
    if (i <1 || i>ListLength_L(*L)) {
        return ERROR;
    }
    for (j=0,p=L->head; j<i-1; j++,p=(LNode*)p->next) ;
    q=(LNode*)p->next;
    *e = q->data;
    p->next = q->next;
    free(q);
    return OK;
}