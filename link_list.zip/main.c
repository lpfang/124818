//
//  main.c
//  List_L
//
//  Created by siqi on 13-10-6.
//  Copyright (c) 2013年 siqi. All rights reserved.
//

#include <stdio.h>
#include "list_l.h"
int main(int argc, const char * argv[])
{
    
    LinkList L;
    int len;
    Status result;
    ElemType e;
    
    InitList_L(&L);

    result = ListInsert_L(&L, 1, 1);
    len = ListLength_L(L);
    // insert code here...
    printf("result: %d  list length is %d!\n",result,len);
    result = ListInsert_L(&L , 2, 2);
    len = ListLength_L(L);
    printf("result: %d  list length is %d!\n",result,len);
    result = ListInsert_L(&L , 3, 3);
    len = ListLength_L(L);
    printf("result: %d  list length is %d!\n",result,len);
    result = ListInsert_L(&L , 3, 4);
    len = ListLength_L(L);
    printf("result: %d  list length is %d!\n",result,len);
    result = ListDelete_L(&L , 3, &e );
    len = ListLength_L(L );
    printf("result: %d  list length is %d!\n",result,len);
    return 0;
}

