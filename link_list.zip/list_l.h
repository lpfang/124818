//
//  list_l.h
//  List_L
//
//  Created by siqi on 13-10-6.
//  Copyright (c) 2013年 siqi. All rights reserved.
//

//#ifndef List_L_list_l_h
//#define List_L_list_l_h


#define TRUE    1
#define FALSE   0
#define OK      1
#define ERROR   0
#define INFEASIBLE  -1
#define OVERFLOW    -2

typedef int Status;
typedef int ElemType;



// definitions for sequential list
#define LIST_INIT_SIZE  100
#define LISTINCREMENT   10

typedef struct SqList{
    ElemType    *elem;
    int         length;
    int         listsize;
} SqList;

typedef struct {
    ElemType    data;
    struct LNode *     next;
} LNode;

typedef struct {
    LNode * head;
} LinkList;

int compare(ElemType e1, ElemType e2);
Status  ListInsert_L(LinkList *, int, ElemType);
Status  ListDelete_L(LinkList *, int i, ElemType *);
Status  InitList_L(LinkList*);
int     ListLength_L(LinkList);
int     isEmpty_L(LinkList);
void    DestroyList(SqList*);
Status  GetElem_L(LinkList, int, ElemType*);
LNode*  LocateElem_Sq(LinkList,ElemType e);
LNode*  PreviousElem_L(LinkList,LNode *);
LNode*  NextElem_L(LinkList,LNode*);
//#endif
