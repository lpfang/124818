//
//  list.h
//  List
//
//  Created by siqi on 13-10-1.
//  Copyright (c) 2013年 siqi. All rights reserved.
//

#ifndef List_list_h
#define List_list_h

#define TRUE    1
#define FALSE   0
#define OK      1
#define ERROR   0
#define INFEASIBLE  -1
#define OVERFLOW    -2

typedef int Status;
typedef int ElemType;



// definitions for sequential list
#define LIST_INIT_SIZE  100
#define LISTINCREMENT   10

typedef struct SqList{
    ElemType    *elem;
    int         length;
    int         listsize;
} SqList;

int compare(ElemType e1, ElemType e2);
Status  ListInsert_Sq(SqList *, int, ElemType);
Status  ListDelete_Sq(SqList *, int i, ElemType *);
Status  InitList_Sq(SqList *);
void    DestroyList(SqList*);
Status  GetElem_Sq(SqList, int, ElemType *);
int  LocateElem_Sq(SqList,ElemType e);

#endif
