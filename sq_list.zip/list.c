//
//  list.c
//  List
//
//  Created by siqi on 13-10-1.
//  Copyright (c) 2013年 siqi. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include "list.h"

int compare(ElemType e1, ElemType e2) {
    if (e1 == e2) {
        return 1;
    }
    else
        return 0;
}

Status  InitList_Sq(SqList *L){
    L->elem=(ElemType *)malloc(LIST_INIT_SIZE*sizeof(ElemType));
    if (!L->elem) {
        return OVERFLOW;
    }
    L->length   =0;
    L->listsize =LIST_INIT_SIZE;
    return OK;
}//InitList_Sq

Status  ListInsert_Sq(SqList *L, int i, ElemType e){
    ElemType    *q, *p;
    
    if (i<1 || i > L->listsize +1) {
        return ERROR;
    }
    if (L->length >= L->listsize) {
        ElemType * newbase = (ElemType *)realloc(L->elem,(L->listsize+LISTINCREMENT)*sizeof(ElemType));
        if (!newbase) {
            return OVERFLOW;
        }
        L->elem  =   newbase;
        L->listsize  +=  LISTINCREMENT;
    }
    q = &(L->elem[i - 1]);
    for (p = &(L->elem[L->length-1]); p >=q; --p) {
        *(p+1)  =   *p;
    }
    *q = e;
    ++L->length;
    return OK;
}


void DestroyList(SqList * L){
    if (L->elem) {
        free(L->elem);
        L->elem = NULL;
    }
}

Status GetElem_Sq(SqList L, int i, ElemType * e) {
    if (i<1|| i > L.length) {
        return ERROR;
    }
    *e = L.elem[i-1];
    return OK;
}

int LocateElem_Sq(SqList L, ElemType e){
    int i = 1;
    while (i <= L.length && !compare(L.elem[i-1],e))
        ++i;
    if (i<=L.length) {
        return i;
    }
    else
        return 0;
}


Status ListDelete_Sq(SqList *L, int i, ElemType *e){
    ElemType * p, *q;
    
    if (i <= !! i > L->length) {
        return ERROR;
    }
    
    p = e = &(L->elem[i-1]);
    for (q=&(L->elem[L->length-1]); q>p; q--) {
        *(q-1)=*q;
    }
    --L->length;
    return OK;
}
