//
//  main.c
//  List
//
//  Created by siqi on 13-10-1.
//  Copyright (c) 2013年 siqi. All rights reserved.
//

#include <stdio.h>
#include "list.h"
int main(int argc, const char * argv[])
{
    SqList aList;
    ElemType e;
    int i=0;
    // insert code here...
    printf("Hello, World!\n");
    
    InitList_Sq(&aList);
    ListInsert_Sq(&aList,1,12);
    ListInsert_Sq(&aList, 2, 34);
    ListInsert_Sq(&aList, 3, 56);
    printf("%d\n",*(aList.elem));
    GetElem_Sq(aList, 2, &e);
    printf("the 2nd element is %d\n",e);
    GetElem_Sq(aList, 3, &e);
    printf("the 3rd element is %d\n",e);
    i = LocateElem_Sq(aList, 56);
    printf("the %d element is 56\n",i);
    ListDelete_Sq(&aList, 2, &e);
    DestroyList(&aList);

    return 0;
}

